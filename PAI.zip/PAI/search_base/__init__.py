"""Exercises for the Principles of AI practices."""
